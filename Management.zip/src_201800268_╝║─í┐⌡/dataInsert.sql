use classDB;



INSERT INTO customer VALUE('sung0320','성치웅',24,NOW());
INSERT INTO customer VALUE('addapp45','제갈수은',18,NOW());
INSERT INTO customer VALUE('allstar1','김수연',19,NOW());
INSERT INTO customer VALUE('application88','안홍기',22,NOW());
INSERT INTO customer VALUE('javajo','이잡수',23,NOW());
INSERT INTO customer VALUE('kim0203','김옥자',18,NOW());
INSERT INTO customer VALUE('qwertyuiop','정기수',21,NOW());

INSERT INTO teacher VALUE('Olympic003','권나라',36,2013);
INSERT INTO teacher VALUE('Olympic010','김유연',32,2014);
INSERT INTO teacher VALUE('Olympic021','안영수',30,2014);
INSERT INTO teacher VALUE('Olympic023','김혁수',29,2016);
INSERT INTO teacher VALUE('inuTEACH','신유현',28,2019);


INSERT INTO class VALUE('입실론','수학','월','10:00:00','13:00:00','Olympic010');
INSERT INTO class VALUE('잉글뤼쉬','영어','목','15:00:00','16:30:00','Olympic010');
INSERT INTO class VALUE('지구는둥그니까','지구과학','토','17:30:00','19:30:00','Olympic021');
INSERT INTO class VALUE('훈민정음','국어','금','13:30:00','16:00:00','Olympic003');